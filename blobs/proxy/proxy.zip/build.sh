docker build -t my-haproxy .
