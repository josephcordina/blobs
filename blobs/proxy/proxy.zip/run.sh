docker run --rm -p:9001:9001 --name my-running-haproxy my-haproxy
